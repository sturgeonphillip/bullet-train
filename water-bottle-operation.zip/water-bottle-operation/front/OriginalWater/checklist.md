# Water to Total Water

front:
[x] WaterProp.ts
[ ] Display.tsx
[x] Bottle.tsx
[x] createBottle.ts
[ ] debouncer.ts

-- [x] DynamicRequestBody
-- [x] DebounceFetchProps (as DebounceTotalOzProps)
-- [x] TotalOzProps
-- [x] BottleProps

back:
[ ] water.routes.ts
[ ] water.controller.ts
