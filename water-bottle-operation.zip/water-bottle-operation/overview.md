# 5 Bottle Component Setups

## Intro

We currently have 5 different attempts at creating this component:

- OriginalWater
- FirstWater
- TotalWater
- BranchWater
- Kerosene

There's similarities and copy/pasted coded, differences, errors, and areas for improvement, but all are broken.

Our goal is one beautiful component that works as expected. Review the 5 we have, see what works and what doesn't, and modify accordingly.

Note: If something doesn't make sense, **please ask for clarity.** I might have accidentally missed an import file that should've been included, or I reference something that did exist at one point but is now no longer anywhere in the provided code.

## Concept

Conceptually, this is a CRUD daily hydration tracker using a Radix Primitive slider for an interactive UI with React Hooks to manage the state of water consumed.

I've set the slider's orientation to vertical and added html and css to so it looks like an empty Nalgene bottle that's filled with water when the user adjusts the slider.
The value goes from 0 to 32 in increments of 4. By default the user's goal is to drink 128 oz each day, so the page starts with 4 empty bottles each day.

The Radix Primitive stores the value as a single element array so a bottle's value is [0] at empty and [16] at halfway full. Beware that this causes some awkward disagreement with TypeScript and React state hooks. We might have discussed a utility function in the past to fix this for storing the data, but I don't think I have that in my code.

We need to capture basic CRUD operations that start each day with 4 empty bottles, which should be simple enough with the Radix slider but there's an issue with state updates in the UI causing excessive fetch requests. While it's a small scale problem right now, I don't want to risk overwhelming the server because someone is chugging water or playing with the slider. I tried to fix this in various ways with some variation of a debouncer or useEffect hook creating a delay so that the update request isn't sent until the slider comes to a complete hault.

## Reference

There was, in fact, a conversation we had in the past about my problems with this component. It's titled [**Water Tracking Architecture Review**](https://chatgpt.com/share/6866b082-c7bc-8010-afd3-9bf765d875de). Look through this to see if there's any decisions made there that I've ignored in this document.

## Action Plan

### Version Notes

If I remember correctly, and if it helps, the chronological order of creating the version is FirstWater, OriginalWater, TotalWater, BranchWater, and then Kerosene.

If they're not the best versions, Kerosene and BranchWater are the two most recent versions, so let's start there. The problem with disregarding the other three is that I don't remember if there's something worth keeping or an altogether better setup that I don't know about or overlooked.

BranchWater's UI functions as intended, it just needs to display the combined total in all of the bottles.

I think Kerosene has the most developed api with routes/controllers.

TotalBottle isn't a full implementation. OriginalWater's setup was too messy and annoying me. I didn't feel confident in how the data was stored. Ultimately I got too annoyed so I decided to just build out the difference with the total ounces across all bottles.

### Storing Data

There's no real reason to track each bottle individually and then also track the total. We decided to stick with only storing the total ounces in the data.

### Presentation

In our previous conversation we talked about the need to show only one interactive slider component and instead show some sort of tally or icon for each bottle completed.

### Future Problems/Stuff to Address Later

Whatever version of this water tracking component we land on, the data storage/schema will become a property on the daily entry along with the rest of the bullet-train features. It will no longer be its own individual piece stored in a json file, so let's be mindful of a future database rewrite. It might not make sense to rebuild a full backend (I'm thinking about the previous talks of Zustand).

**We can disregard/hold off on the following stuff for now.**

There's currently a broken button component labelled "Add Bottle" that is intended to add an additional bottle, should a user drink more and want to store that information.

The new presentation will need a way to delete any completed bottles if the user made a mistake or for some reason got trigger happy sliding up and down for the visual effects.
